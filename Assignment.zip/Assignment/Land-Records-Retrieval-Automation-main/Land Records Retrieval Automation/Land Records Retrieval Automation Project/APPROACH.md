# Approach

## Overall Architecture

The app is split into two parts:

1. **Backend API + Automation Worker**
   - Express API receives ROR 1B retrieval requests.
   - Job runner stores job status and logs.
   - Playwright opens the MeeBhoomi ROR page and performs the search.
   - When CAPTCHA appears, automation captures the CAPTCHA image and pauses.
   - The frontend submits CAPTCHA text, then automation resumes.
   - Final output is saved into the configured downloads directory.

2. **Frontend Dashboard**
   - React/Vite UI accepts land record search inputs.
   - The UI polls job status every 1.5 seconds.
   - When status becomes `waiting_captcha`, the CAPTCHA modal is shown.
   - When completed, a download link is shown.

## Job Lifecycle

```text
queued → running → waiting_captcha → running → completed
                               ↘ failed
```

## ASP.NET WebForms Handling

MeeBhoomi uses ASP.NET WebForms style pages. These pages often include:

- ViewState
- event validation
- server-side postbacks
- dropdowns that populate only after the previous dropdown changes
- dynamic IDs after portal updates

This implementation handles that by:

- using browser-level automation instead of raw HTTP scraping
- selecting dropdowns in order: District → Mandal → Village
- waiting after each selection for postback/dynamic loading
- using multiple selector fallbacks
- retrying flaky navigation steps

## CAPTCHA Handling

The project does not bypass CAPTCHA.

Flow:

1. Playwright captures CAPTCHA image from the portal.
2. Backend stores the CAPTCHA image as a base64 data URL in the job.
3. Frontend shows the image to the user.
4. User enters CAPTCHA text.
5. Backend resumes the same automation job.

## Output Handling

Preferred output is PDF. If the portal does not expose a direct PDF/download button, the automation saves the current page using Playwright PDF generation. If PDF generation is unavailable, it saves HTML as a fallback.

## Challenges Faced

- CAPTCHA requires human input and cannot be automated ethically.
- MeeBhoomi may change element IDs without notice.
- ASP.NET postbacks can make dropdown handling flaky.
- Portal performance may be slow or unstable.
- Some results may open in popups or print windows.
- PDF output may depend on browser rendering and portal print behavior.

## Assumptions Made

- The user has valid land record search input.
- Dropdown options are entered using the exact portal spelling.
- The portal allows normal browser access from the running machine.
- The generated document is for lawful and authorized use.
- CAPTCHA is entered manually by the user.

## Limitations

- Job storage is in-memory, so jobs reset when backend restarts.
- Selectors may need updates if MeeBhoomi changes UI structure.
- Current version runs one Playwright session per job.
- No authentication is included by default.
- Cloud storage is not implemented, but local downloads are supported.

## Production Improvements

- Use Redis/BullMQ for background jobs.
- Store job records in PostgreSQL or MongoDB.
- Store files in cloud storage.
- Add user authentication and audit logging.
- Add rate limiting and queue concurrency control.
- Add Playwright tracing/video for failed jobs.
- Add district/mandal/village lookup caching.
- Add Telangana EC automation as `/automation/telanganaEc.js` and reuse the same job runner pattern.
