# MeeBhoomi ROR 1B Retrieval Automation

Full-stack automation system to retrieve ROR 1B land record documents from the Andhra Pradesh MeeBhoomi portal using Node.js, Playwright, and React.

> Important: This project uses human-in-the-loop CAPTCHA. It does not bypass CAPTCHA or use third-party CAPTCHA solving services.

## Features

- Clean dashboard for District, Mandal/Zone, Village, search type, and search value
- REST API for job creation, polling status, CAPTCHA submission, and file download
- Playwright automation worker for MeeBhoomi ROR 1B search flow
- CAPTCHA image capture and manual UI submission
- Status lifecycle: `queued`, `running`, `waiting_captcha`, `completed`, `failed`
- Output saving as PDF where possible, with HTML fallback
- Headless/headed browser support using `HEADLESS=false`
- Step-by-step logs for traceability
- Selector fallback strategy for ASP.NET WebForms pages
- Retry helper and clear error handling
- Sample test for selector/helper logic

## Project Structure

```text
/backend
  /src
    automation/meebhoomiRor1b.js
    routes/jobs.js
    services/jobRunner.js
    services/jobStore.js
    utils/captcha.js
    utils/browser.js
    utils/selectors.js
  /tests
    selectors.test.js
/frontend
  /src
    pages/Dashboard.tsx
    components/JobStatus.tsx
    components/CaptchaModal.tsx
    services/api.ts
config.example.json
.env.example
README.md
APPROACH.md
```

## Prerequisites

- Node.js 20 or higher recommended
- npm
- Chromium installed through Playwright

## Setup

```bash
cd meebhoomi-ror1b-automation
cp .env.example backend/.env
npm run install:all
npm run --prefix backend playwright:install
```

## Run Locally

Terminal 1:

```bash
cd backend
npm run dev
```

Terminal 2:

```bash
cd frontend
npm run dev
```

Open:

```text
http://localhost:5173
```

## Environment Variables

Create `backend/.env`:

```env
PORT=4000
FRONTEND_URL=http://localhost:5173
MEEBHOOMI_BASE_URL=https://meebhoomi.ap.gov.in
MEEBHOOMI_ROR_URL=https://meebhoomi.ap.gov.in/SearchROR.aspx
HEADLESS=true
SLOW_MO=0
JOB_TIMEOUT_MS=180000
DOWNLOAD_DIR=../downloads
```

For debugging browser steps:

```env
HEADLESS=false
SLOW_MO=200
```

## API Design

### Create ROR 1B Retrieval Job

```bash
curl -X POST http://localhost:4000/api/jobs/ror1b \
  -H "Content-Type: application/json" \
  -d '{
    "district": "Guntur",
    "mandal": "Tenali",
    "village": "Kolakaluru",
    "searchType": "surveyNumber",
    "searchValue": "123"
  }'
```

Allowed `searchType` values:

```text
surveyNumber
accountNumber
aadhaarNumber
pattadarName
```

### Check Job Status

```bash
curl http://localhost:4000/api/jobs/<JOB_ID>
```

### Submit CAPTCHA

```bash
curl -X POST http://localhost:4000/api/jobs/<JOB_ID>/captcha \
  -H "Content-Type: application/json" \
  -d '{ "captcha": "ABCD12" }'
```

### Download Generated Document

```bash
curl -L http://localhost:4000/api/jobs/<JOB_ID>/download -o ror1b-output.pdf
```

## Run Tests

```bash
cd backend
npm test
```

## Notes for Real Portal Use

MeeBhoomi is an ASP.NET WebForms portal. Dropdown IDs and page behavior can change. This project includes fallback selectors, but you may need to adjust selectors after inspecting the live portal in headed mode.

Recommended debugging:

```bash
HEADLESS=false SLOW_MO=300 npm run dev
```

## Future Improvements

- Persist jobs in Redis/PostgreSQL instead of in-memory Map
- Add BullMQ queue for production worker scaling
- Store output in S3/Azure Blob/GCS
- Add authentication for users
- Add dropdown metadata caching
- Add Telangana EC automation as a second automation module
