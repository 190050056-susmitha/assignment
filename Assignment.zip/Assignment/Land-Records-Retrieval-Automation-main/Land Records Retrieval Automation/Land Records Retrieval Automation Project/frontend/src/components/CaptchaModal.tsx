import { useState } from 'react';

export default function CaptchaModal({ image, onSubmit }: { image: string; onSubmit: (value: string) => Promise<void> }) {
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);

  async function handleSubmit() {
    if (!value.trim()) return;
    setBusy(true);
    try {
      await onSubmit(value.trim());
      setValue('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h2>Enter CAPTCHA</h2>
        <p>The portal requires human verification. Type the text shown below.</p>
        <img src={image} className="captcha-img" alt="CAPTCHA from MeeBhoomi portal" />
        <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="CAPTCHA text" />
        <button onClick={handleSubmit} disabled={busy}>{busy ? 'Submitting...' : 'Resume Retrieval'}</button>
      </div>
    </div>
  );
}
