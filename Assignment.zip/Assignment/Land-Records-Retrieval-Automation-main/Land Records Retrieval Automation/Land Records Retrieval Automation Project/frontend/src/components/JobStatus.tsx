import { downloadUrl } from '../services/api';

export default function JobStatus({ job }: { job: any }) {
  if (!job) return null;
  return (
    <section className="card status-card">
      <div className="status-header">
        <div>
          <h2>Job Status</h2>
          <p className="muted">Job ID: {job.id}</p>
        </div>
        <span className={`badge ${job.status}`}>{job.status}</span>
      </div>

      {job.error && <div className="error-box">{job.error}</div>}
      {job.status === 'completed' && <a className="download" href={downloadUrl(job.id)}>Download ROR 1B Output</a>}

      <h3>Logs</h3>
      <div className="logs">
        {(job.logs || []).map((log: any, index: number) => (
          <div key={index} className={`log ${log.level}`}>
            <span>{new Date(log.ts).toLocaleTimeString()}</span> {log.message}
          </div>
        ))}
      </div>
    </section>
  );
}
