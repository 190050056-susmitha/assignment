const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

export async function createRorJob(payload: unknown) {
  const res = await fetch(`${API_BASE}/api/jobs/ror1b`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Unable to create job');
  return res.json();
}

export async function getJob(id: string) {
  const res = await fetch(`${API_BASE}/api/jobs/${id}`);
  if (!res.ok) throw new Error((await res.json()).error || 'Unable to fetch job');
  return res.json();
}

export async function submitCaptcha(id: string, captcha: string) {
  const res = await fetch(`${API_BASE}/api/jobs/${id}/captcha`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ captcha })
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Unable to submit CAPTCHA');
  return res.json();
}

export function downloadUrl(id: string) {
  return `${API_BASE}/api/jobs/${id}/download`;
}
