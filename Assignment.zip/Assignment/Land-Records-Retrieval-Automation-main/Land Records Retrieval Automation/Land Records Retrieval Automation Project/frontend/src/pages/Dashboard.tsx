import { useEffect, useState } from 'react';
import { createRorJob, getJob, submitCaptcha } from '../services/api';
import JobStatus from '../components/JobStatus';
import CaptchaModal from '../components/CaptchaModal';

const initialForm = {
  district: '',
  mandal: '',
  village: '',
  searchType: 'surveyNumber',
  searchValue: ''
};

export default function Dashboard() {
  const [form, setForm] = useState(initialForm);
  const [jobId, setJobId] = useState('');
  const [job, setJob] = useState<any>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!jobId) return;
    const timer = setInterval(async () => {
      try {
        setJob(await getJob(jobId));
      } catch (err: any) {
        setError(err.message);
      }
    }, 1500);
    return () => clearInterval(timer);
  }, [jobId]);

  async function startJob(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    try {
      const created = await createRorJob(form);
      setJobId(created.id);
      setJob(created);
    } catch (err: any) {
      setError(err.message);
    }
  }

  async function handleCaptcha(value: string) {
    await submitCaptcha(job.id, value);
    setJob(await getJob(job.id));
  }

  return (
    <main className="layout">
      <section className="hero">
        <div>
          <p className="eyebrow">Andhra Pradesh Land Records</p>
          <h1>MeeBhoomi ROR 1B Automation Portal</h1>
          <p>Search MeeBhoomi, handle CAPTCHA manually, track automation progress, and download the generated output.</p>
        </div>
      </section>

      <section className="grid">
        <form className="card form" onSubmit={startJob}>
          <h2>Start Retrieval</h2>
          <label>District<input value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} placeholder="Example: Guntur" /></label>
          <label>Mandal / Zone<input value={form.mandal} onChange={(e) => setForm({ ...form, mandal: e.target.value })} placeholder="Example: Tenali" /></label>
          <label>Village<input value={form.village} onChange={(e) => setForm({ ...form, village: e.target.value })} placeholder="Example: Kolakaluru" /></label>
          <label>Search Type
            <select value={form.searchType} onChange={(e) => setForm({ ...form, searchType: e.target.value })}>
              <option value="surveyNumber">Survey Number</option>
              <option value="accountNumber">Account Number / Khata</option>
              <option value="aadhaarNumber">Aadhaar Number</option>
              <option value="pattadarName">Pattadar Name</option>
            </select>
          </label>
          <label>Search Value<input value={form.searchValue} onChange={(e) => setForm({ ...form, searchValue: e.target.value })} placeholder="Enter value" /></label>
          <button type="submit">Start Retrieval</button>
          {error && <div className="error-box">{error}</div>}
        </form>
        <JobStatus job={job} />
      </section>

      {job?.status === 'waiting_captcha' && job.captchaImage && <CaptchaModal image={job.captchaImage} onSubmit={handleCaptcha} />}
    </main>
  );
}
