import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import jobsRouter from './routes/jobs.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;
const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';

app.use(cors({ origin: frontendUrl }));
app.use(express.json({ limit: '2mb' }));

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'meebhoomi-ror1b-backend' }));
app.use('/api/jobs', jobsRouter);

const downloadDir = path.resolve(__dirname, '../../', process.env.DOWNLOAD_DIR || '../downloads');
app.use('/downloads', express.static(downloadDir));

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
