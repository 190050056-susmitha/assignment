export async function captureCaptcha(page, selectors) {
  for (const selector of selectors) {
    const locator = page.locator(selector).first();
    if (await locator.count()) {
      try {
        await locator.waitFor({ state: 'visible', timeout: 5000 });
        const buffer = await locator.screenshot({ timeout: 5000 });
        return `data:image/png;base64,${buffer.toString('base64')}`;
      } catch {
        // try next selector
      }
    }
  }
  throw new Error('CAPTCHA image was not found on the portal page');
}
