export const SELECTORS = {
  district: ['#ddl_dist', '#ddlDistrict', 'select[name*=District i]', 'select[id*=dist i]'],
  mandal: ['#ddl_mand', '#ddlMandal', 'select[name*=Mandal i]', 'select[id*=mand i]'],
  village: ['#ddl_vill', '#ddlVillage', 'select[name*=Village i]', 'select[id*=vill i]'],
  captchaImage: ['#imgCaptcha', 'img[src*=Captcha i]', 'img[id*=captcha i]'],
  captchaInput: ['#txtCaptcha', 'input[name*=Captcha i]', 'input[id*=captcha i]'],
  submit: ['#btn_submit', '#btnSubmit', 'input[type=submit]', 'button:has-text("Submit")'],
  resultsTable: ['table:has-text("Khata")', 'table:has-text("Pattadar")', '#GridView1', 'table']
};

export function searchFieldSelectors(searchType) {
  const map = {
    surveyNumber: ['#txtSurveyNo', 'input[name*=Survey i]', 'input[id*=survey i]'],
    accountNumber: ['#txtKhataNo', 'input[name*=Khata i]', 'input[name*=Account i]', 'input[id*=khata i]'],
    aadhaarNumber: ['#txtAadhaar', 'input[name*=Aadhaar i]', 'input[id*=aadhaar i]'],
    pattadarName: ['#txtPattadarName', 'input[name*=Pattadar i]', 'input[name*=Name i]', 'input[id*=pattadar i]']
  };
  return map[searchType] || [];
}

export function normalizeSearchType(value) {
  const normalized = String(value || '').trim();
  const allowed = ['surveyNumber', 'accountNumber', 'aadhaarNumber', 'pattadarName'];
  if (!allowed.includes(normalized)) throw new Error(`Unsupported search type: ${value}`);
  return normalized;
}
