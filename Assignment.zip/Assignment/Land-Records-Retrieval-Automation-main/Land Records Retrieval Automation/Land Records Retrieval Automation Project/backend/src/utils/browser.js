import { chromium } from 'playwright';

export async function launchBrowser() {
  const headless = String(process.env.HEADLESS ?? 'true').toLowerCase() !== 'false';
  const slowMo = Number(process.env.SLOW_MO || 0);
  return chromium.launch({ headless, slowMo });
}

export async function withRetry(task, { retries = 2, label = 'operation', onRetry = () => {} } = {}) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      return await task(attempt);
    } catch (err) {
      lastError = err;
      if (attempt < retries) {
        onRetry(`${label} failed on attempt ${attempt + 1}. Retrying...`);
        await new Promise((resolve) => setTimeout(resolve, 1000 * (attempt + 1)));
      }
    }
  }
  throw lastError;
}
