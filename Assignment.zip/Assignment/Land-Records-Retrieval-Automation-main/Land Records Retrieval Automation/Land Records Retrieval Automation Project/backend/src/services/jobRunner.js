import { nanoid } from 'nanoid';
import { createJobRecord, getJob, patchJob, addLog } from './jobStore.js';
import { retrieveRor1B } from '../automation/meebhoomiRor1b.js';

const running = new Set();

export function startRor1bJob(input) {
  const id = nanoid(10);
  const job = createJobRecord(id, input);
  queueMicrotask(() => runJob(id));
  return job;
}

async function runJob(id) {
  if (running.has(id)) return;
  running.add(id);
  patchJob(id, { status: 'running' });
  addLog(id, 'Job started');

  try {
    const outputPath = await retrieveRor1B({
      jobId: id,
      input: getJob(id).input,
      onLog: (msg, level) => addLog(id, msg, level),
      onCaptcha: async (captchaImage) => {
        patchJob(id, { status: 'waiting_captcha', captchaImage, captchaSubmitted: null });
        addLog(id, 'Waiting for human CAPTCHA input');
        return waitForCaptcha(id);
      }
    });

    patchJob(id, { status: 'completed', outputPath, captchaImage: null });
    addLog(id, 'Job completed successfully');
  } catch (err) {
    patchJob(id, { status: 'failed', error: err.message || String(err) });
    addLog(id, `Job failed: ${err.message || err}`, 'error');
  } finally {
    running.delete(id);
  }
}

async function waitForCaptcha(id) {
  const timeoutMs = Number(process.env.JOB_TIMEOUT_MS || 180000);
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const job = getJob(id);
    if (!job) throw new Error('Job not found while waiting for CAPTCHA');
    if (job.captchaSubmitted) return job.captchaSubmitted;
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  throw new Error('CAPTCHA input timed out');
}

export function submitCaptcha(id, value) {
  const job = getJob(id);
  if (!job) return null;
  if (job.status !== 'waiting_captcha') {
    throw new Error('Job is not waiting for CAPTCHA');
  }
  patchJob(id, { captchaSubmitted: value, status: 'running' });
  addLog(id, 'CAPTCHA submitted by user');
  return getJob(id);
}
