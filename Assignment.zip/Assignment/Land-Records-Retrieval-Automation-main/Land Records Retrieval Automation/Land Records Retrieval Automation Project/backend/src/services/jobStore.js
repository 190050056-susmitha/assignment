const jobs = new Map();

export function createJobRecord(id, input) {
  const job = {
    id,
    input,
    status: 'queued',
    logs: [],
    captchaImage: null,
    captchaSubmitted: null,
    outputPath: null,
    error: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  jobs.set(id, job);
  return job;
}

export function getJob(id) {
  return jobs.get(id);
}

export function patchJob(id, patch) {
  const job = getJob(id);
  if (!job) return null;
  Object.assign(job, patch, { updatedAt: new Date().toISOString() });
  jobs.set(id, job);
  return job;
}

export function addLog(id, message, level = 'info') {
  const job = getJob(id);
  if (!job) return;
  job.logs.push({ ts: new Date().toISOString(), level, message });
  job.updatedAt = new Date().toISOString();
}
