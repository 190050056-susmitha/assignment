import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { startRor1bJob, submitCaptcha } from '../services/jobRunner.js';
import { getJob } from '../services/jobStore.js';

const router = express.Router();

function validateInput(body) {
  const required = ['district', 'mandal', 'village', 'searchType', 'searchValue'];
  const missing = required.filter((key) => !body[key] || String(body[key]).trim() === '');
  if (missing.length) return `Missing required fields: ${missing.join(', ')}`;
  const allowed = ['surveyNumber', 'accountNumber', 'aadhaarNumber', 'pattadarName'];
  if (!allowed.includes(body.searchType)) return `Invalid searchType. Allowed: ${allowed.join(', ')}`;
  return null;
}

router.post('/ror1b', (req, res) => {
  const error = validateInput(req.body);
  if (error) return res.status(400).json({ error });
  const job = startRor1bJob(req.body);
  res.status(202).json({ id: job.id, status: job.status });
});

router.get('/:id', (req, res) => {
  const job = getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});

router.post('/:id/captcha', (req, res) => {
  try {
    if (!req.body?.captcha) return res.status(400).json({ error: 'captcha is required' });
    const job = submitCaptcha(req.params.id, req.body.captcha);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    res.json({ id: job.id, status: job.status });
  } catch (err) {
    res.status(409).json({ error: err.message });
  }
});

router.get('/:id/download', (req, res) => {
  const job = getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.status !== 'completed' || !job.outputPath) return res.status(409).json({ error: 'Document is not ready' });

  const absolutePath = path.resolve(job.outputPath);
  if (!fs.existsSync(absolutePath)) return res.status(404).json({ error: 'Generated file not found' });
  res.download(absolutePath);
});

export default router;
