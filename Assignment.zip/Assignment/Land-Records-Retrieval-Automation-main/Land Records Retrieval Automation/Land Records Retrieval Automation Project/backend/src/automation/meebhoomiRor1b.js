import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { launchBrowser, withRetry } from '../utils/browser.js';
import { captureCaptcha } from '../utils/captcha.js';
import { SELECTORS, searchFieldSelectors, normalizeSearchType } from '../utils/selectors.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function clickFirst(page, selectors, label) {
  for (const selector of selectors) {
    const locator = page.locator(selector).first();
    if (await locator.count()) {
      try {
        await locator.click({ timeout: 7000 });
        return selector;
      } catch {
        // try next selector
      }
    }
  }
  throw new Error(`${label} control was not found`);
}

async function fillFirst(page, selectors, value, label) {
  for (const selector of selectors) {
    const locator = page.locator(selector).first();
    if (await locator.count()) {
      try {
        await locator.fill(String(value), { timeout: 7000 });
        return selector;
      } catch {
        // try next selector
      }
    }
  }
  throw new Error(`${label} field was not found`);
}

async function selectByLabelOrValue(page, selectors, value, label) {
  for (const selector of selectors) {
    const locator = page.locator(selector).first();
    if (!(await locator.count())) continue;

    try {
      await locator.waitFor({ state: 'visible', timeout: 10000 });
      await Promise.allSettled([
        page.waitForLoadState('networkidle', { timeout: 8000 }),
        locator.selectOption({ label: String(value) }, { timeout: 8000 })
      ]);
      return selector;
    } catch {
      try {
        await Promise.allSettled([
          page.waitForLoadState('networkidle', { timeout: 8000 }),
          locator.selectOption({ value: String(value) }, { timeout: 8000 })
        ]);
        return selector;
      } catch {
        // try next selector
      }
    }
  }
  throw new Error(`${label} dropdown option was not found. Try exact portal spelling.`);
}

async function saveFallback(page, jobId) {
  const downloadDir = path.resolve(__dirname, '../../../', process.env.DOWNLOAD_DIR || '../downloads');
  await fs.mkdir(downloadDir, { recursive: true });
  const pdfPath = path.join(downloadDir, `${jobId}-ror1b.pdf`);
  const htmlPath = path.join(downloadDir, `${jobId}-ror1b.html`);
  try {
    await page.pdf({ path: pdfPath, format: 'A4', printBackground: true });
    return pdfPath;
  } catch {
    await fs.writeFile(htmlPath, await page.content(), 'utf8');
    return htmlPath;
  }
}

async function trySavePortalDownload(page, jobId, onLog) {
  const downloadDir = path.resolve(__dirname, '../../../', process.env.DOWNLOAD_DIR || '../downloads');
  await fs.mkdir(downloadDir, { recursive: true });
  try {
    const popupPromise = page.waitForEvent('popup', { timeout: 5000 }).catch(() => null);
    const link = page.locator('a:has-text("Print"), a:has-text("Download"), input[value*=Print i], button:has-text("Print")').first();
    if (await link.count()) {
      const downloadPromise = page.waitForEvent('download', { timeout: 8000 }).catch(() => null);
      await link.click({ timeout: 5000 });
      const download = await downloadPromise;
      if (download) {
        const finalPath = path.join(downloadDir, `${jobId}-${download.suggestedFilename() || 'ror1b.pdf'}`);
        await download.saveAs(finalPath);
        return finalPath;
      }
      const popup = await popupPromise;
      if (popup) {
        await popup.waitForLoadState('domcontentloaded', { timeout: 10000 }).catch(() => {});
        return await saveFallback(popup, `${jobId}-popup`);
      }
    }
  } catch (err) {
    onLog(`Could not use portal download/print button: ${err.message}`, 'warn');
  }
  return await saveFallback(page, jobId);
}

export async function retrieveRor1B({ jobId, input, onLog, onCaptcha }) {
  normalizeSearchType(input.searchType);
  const browser = await launchBrowser();
  const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 } });
  const page = await context.newPage();
  page.setDefaultTimeout(30000);

  try {
    const url = process.env.MEEBHOOMI_ROR_URL || 'https://meebhoomi.ap.gov.in/SearchROR.aspx';
    await withRetry(
      () => page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 }),
      { label: 'Opening MeeBhoomi ROR page', onRetry: onLog }
    );
    onLog('MeeBhoomi ROR page opened');

    await selectByLabelOrValue(page, SELECTORS.district, input.district, 'District');
    onLog(`District selected: ${input.district}`);
    await page.waitForTimeout(1200);

    await selectByLabelOrValue(page, SELECTORS.mandal, input.mandal, 'Mandal/Zone');
    onLog(`Mandal selected: ${input.mandal}`);
    await page.waitForTimeout(1200);

    await selectByLabelOrValue(page, SELECTORS.village, input.village, 'Village');
    onLog(`Village selected: ${input.village}`);

    await fillFirst(page, searchFieldSelectors(input.searchType), input.searchValue, 'Search value');
    onLog(`Search value entered for ${input.searchType}`);

    const captchaImage = await captureCaptcha(page, SELECTORS.captchaImage);
    const captchaText = await onCaptcha(captchaImage);
    await fillFirst(page, SELECTORS.captchaInput, captchaText, 'CAPTCHA');
    onLog('CAPTCHA entered. Submitting form.');

    await Promise.allSettled([
      page.waitForLoadState('networkidle', { timeout: 15000 }),
      clickFirst(page, SELECTORS.submit, 'Submit')
    ]);

    const noRecord = page.getByText(/no records|not found|no data/i).first();
    if (await noRecord.count()) {
      throw new Error('No records found for the provided search input');
    }

    const resultTable = page.locator(SELECTORS.resultsTable.join(', ')).first();
    await resultTable.waitFor({ state: 'visible', timeout: 30000 });
    onLog('Results table found');

    const ownerLink = page.locator('table a, #GridView1 a').first();
    if (await ownerLink.count()) {
      await Promise.allSettled([
        page.waitForLoadState('networkidle', { timeout: 15000 }),
        ownerLink.click({ timeout: 7000 })
      ]);
      onLog('Opened first available Khata/owner record');
    } else {
      onLog('No clickable owner link found. Saving current result page.', 'warn');
    }

    const outputPath = await trySavePortalDownload(page, jobId, onLog);
    onLog(`Output saved: ${outputPath}`);
    return outputPath;
  } finally {
    await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }
}
