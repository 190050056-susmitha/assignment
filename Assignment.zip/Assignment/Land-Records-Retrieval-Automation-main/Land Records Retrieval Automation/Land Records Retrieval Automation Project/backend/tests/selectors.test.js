import test from 'node:test';
import assert from 'node:assert/strict';
import { searchFieldSelectors, normalizeSearchType } from '../src/utils/selectors.js';

test('returns selectors for survey number', () => {
  const selectors = searchFieldSelectors('surveyNumber');
  assert.ok(selectors.some((selector) => selector.toLowerCase().includes('survey')));
});

test('throws for unsupported search type', () => {
  assert.throws(() => normalizeSearchType('mobileNumber'), /Unsupported search type/);
});
